package utils;

import java.io.File;
import java.net.URL;

import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;			
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.remote.MobilePlatform;
import models.EventModel;

public class Utils {	
	
	public static AppiumDriver getAndroidDriver(URL serverUrl, File app) {
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability(MobileCapabilityType.APP, app.getAbsolutePath());
		capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, MobilePlatform.ANDROID);
		capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "emulator-5554");
		capabilities.setCapability(MobileCapabilityType.BROWSER_NAME, "");
		capabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION, "9");
		capabilities.setCapability(MobileCapabilityType.APP_PACKAGE, "ua_olkr.guestlistcontroller");
		capabilities.setCapability(MobileCapabilityType.APP_ACTIVITY, ".StartActivity");
		capabilities.setCapability("autoGrantPermissions", true);

		return new AndroidDriver(serverUrl, capabilities);
	}
	
	public static EventModel createEventModel(
			String eventName, 
			String eventPlace, 
			String eventAddress, 
			String eventDate, 
			String eventTime) {
		return new EventModel(eventName, eventPlace, eventAddress, eventDate, eventTime);
	}
}

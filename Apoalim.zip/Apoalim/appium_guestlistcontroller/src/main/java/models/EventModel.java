package models;

public class EventModel {
	public String mEventName;
    public String mEventPlace;
    public String mEventAddress;
    public String mEventDate;
    public String mEventTime;
    
    public EventModel(String eventName, String eventPlace, String eventAddress, String eventDate, String eventTime) {
        this.mEventName = eventName;
        this.mEventPlace = eventPlace;
        this.mEventAddress = eventAddress;
        this.mEventDate = eventDate;
        this.mEventTime = eventTime;
    }

    public EventModel() { }

    public String getEventName() {
        return mEventName;
    }

    public String getEventPlace() {
        return mEventPlace;
    }

    public String getEventAddress() {
        return mEventAddress;
    }

    public String getEventDate() {
        return mEventDate;
    }

    public String getEventTime() {
        return mEventTime;
    }

    public void setEventName(String eventName) {
        this.mEventName = eventName;
    }

    public void setEventPlace(String eventPlace) {
        this.mEventPlace = eventPlace;
    }

    public void setEventAddress(String eventAddress) {
        this.mEventAddress = eventAddress;
    }

    public void setEventDate(String eventDate) {
        this.mEventDate = eventDate;
    }

    public void setEventTime(String eventTime) {
        this.mEventTime = eventTime;
    }
}

package ua_olkr.guestlistcontroller.appium_guestlistcontroller;

import java.io.File;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.appium.java_client.AppiumDriver;
import models.EventModel;
import utils.Utils;


public class EventChooseActTest {

	AppiumDriver mDriver = null;
	EventModel mEventModel = null;	
	int LENGHT = 3;
	String [] arrNames = new String[] {
			"", 
			"name 12345", 
			"name$name*name@ name, name&name"};
	String [] arrPlaces = new String[] {
			"", 
			"place 12345",
			"place$place*place@ place, place&place"};
	String [] arrAddresses = new String[] {
			"", 
			"address 12345", 
			"address$address*address@ address, address&address"};
	
	@BeforeTest
	private void getAppiumDriver() throws Exception {
		URL url = new URL("http://127.0.0.1:4723/wd/hub");
		File fileDir = new File(System.getProperty("user.dir"));
		File app = new File(fileDir, "app-release.apk");
		mDriver = Utils.getAndroidDriver(url, app);
						
		mDriver.manage().timeouts().implicitlyWait(10,  TimeUnit.SECONDS);
		mDriver.resetApp();
	}
	
//	@Test
	private void openAddNewEventWindow() {
		WebElement element = mDriver.findElement(By.id("ua_olkr.guestlistcontroller:id/add_new_event"));
		element.click();
	}
	
	/*
	 *  Test1 with pass date
	 */
	@Test
	public void test1() throws Exception {
		for(int i=0; i<LENGHT; i++) {
			openAddNewEventWindow();
			setPassDateOfNewEvent();
			setTimeOfNewEvent();			
			setNameOfNewEvent(i);
			setPlaceOfNewEvent(i);
			setAddressOfNewEvent(i);
			createNewEvent();
		}		
	}
	
	/*
	 *  Test2 with current date
	 */
	@Test
	public void test2() throws Exception {
		for(int i=0; i<LENGHT; i++) {
			openAddNewEventWindow();
			setCurrentDateOfNewEvent();
			setTimeOfNewEvent();			
			setNameOfNewEvent(i);
			setPlaceOfNewEvent(i);
			setAddressOfNewEvent(i);
			createNewEvent();
		}		
	}
	
	/*
	 *  Test3 with valid date
	 */
	@Test
	public void test3() throws Exception {
		for(int i=0; i<LENGHT; i++) {
			openAddNewEventWindow();
			setValidDateOfNewEvent();
			setTimeOfNewEvent();			
			setNameOfNewEvent(i);
			setPlaceOfNewEvent(i);
			setAddressOfNewEvent(i);
			createNewEvent();
		}		
	}
	
	private void setPassDateOfNewEvent() {
		WebElement elementDate = mDriver.findElement(By.id("ua_olkr.guestlistcontroller:id/tvDateAddNewEvent"));
		elementDate.click();
		mDriver.findElement(By.xpath("//android.view.View[@content-desc=\"20 August 2019\"]")).click();
		mDriver.findElement(By.id("android:id/button1")).click();
	}
	
	private void setCurrentDateOfNewEvent() {
		WebElement elementDate = mDriver.findElement(By.id("ua_olkr.guestlistcontroller:id/tvDateAddNewEvent"));
		elementDate.click();
		mDriver.findElement(By.xpath("//android.view.View[@content-desc=\"21 August 2019\"]")).click();
		mDriver.findElement(By.id("android:id/button1")).click();
	}
	
	private void setValidDateOfNewEvent() {
		WebElement elementDate = mDriver.findElement(By.id("ua_olkr.guestlistcontroller:id/tvDateAddNewEvent"));
		elementDate.click();
		mDriver.findElement(By.xpath("//android.view.View[@content-desc=\"22 August 2019\"]")).click();
		mDriver.findElement(By.id("android:id/button1")).click();
	}
	
	private void setTimeOfNewEvent() {
		WebElement elementTime = mDriver.findElement(By.id("ua_olkr.guestlistcontroller:id/tvTimeAddNewEvent"));
		elementTime.click();
		mDriver.findElement(By.id("android:id/hours")).click();
		mDriver.findElement(By.xpath("//android.widget.RadialTimePickerView.RadialPickerTouchHelper[@content-desc=\"6\"]")).click();
		
		mDriver.findElement(By.id("android:id/minutes")).click();
		mDriver.findElement(By.xpath("//android.widget.RadialTimePickerView.RadialPickerTouchHelper[@content-desc=\"0\"]")).click();
		
		mDriver.findElement(By.id("android:id/button1")).click();		
	}		
	
	private void setNameOfNewEvent(int count) {
		WebElement elementName = mDriver.findElement(By.id("ua_olkr.guestlistcontroller:id/etNewEventName"));		
		elementName.sendKeys(arrNames[count]);
		System.out.println("arrNames" + " " + (count+1) + " " + arrNames[count]);
	}
	
	private void setPlaceOfNewEvent(int count) {
		WebElement elementLocation = mDriver.findElement(By.id("ua_olkr.guestlistcontroller:id/etPlaceAddNewEvent"));
		elementLocation.sendKeys(arrPlaces[count]);
		System.out.println("arrPlaces" + " " + (count+1) + " " + arrPlaces[count]);
	}
	
	private void setAddressOfNewEvent(int count) {
		WebElement elementAddress = mDriver.findElement(By.id("ua_olkr.guestlistcontroller:id/etAddressAddNewEvent"));
		elementAddress.sendKeys(arrAddresses[count]);
		System.out.println("arrAddresses" + " " + (count+1) + " " + arrAddresses[count]);
	}
	
	private void createNewEvent() throws Exception {
		WebElement element = mDriver.findElement(By.id("ua_olkr.guestlistcontroller:id/edit_guest_ok"));
		element.click();
	}
	
	@AfterClass
    public void driverDown() throws Exception {
		mDriver.quit();
    }
}			
